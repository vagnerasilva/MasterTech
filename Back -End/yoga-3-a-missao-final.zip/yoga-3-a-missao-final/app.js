var express = require('express');
var app = express();
var http = require('http');
var bodyParser = require('body-parser');

app.set('view engine', 'ejs');
app.use(express.static('public'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));


// Principal
app.get('/', function(req, res) {
  var indiceRandomico = Math.floor( Math.random() * frases.length )
  var fraseEscolhida  = frases[indiceRandomico];

  res.render('index', { frase: fraseEscolhida })
});

// Sobre
app.get('/sobre', function(req, res) {
  var topicos = [
    { title: 'Método',   body: 'O Método DeRose é uma proposta de alta performance e qualidade de vida que tem por objetivo o desenvolvimento pessoal do ser humano (autoconhecimento) e suas boas relações.' },
    { title: 'Proposta', body: 'Nossa proposta engloba técnicas e conceitos. As técnicas irão incrementar no praticante: reforço na estrutura biológica, força, flexibilidade, energia, disposição, concentração mental, foco e alta performance na vida.' },
    { title: 'Conceito', body: 'Já os conceitos são o alicerce dessa cultura. São transmitidos no dia-a-dia, no convívio diário, nos cursos, eventos, confraternizações. Permitem ao aluno inserir novos e melhores hábitos de vida no seu cotidiano.' },
  ]
  res.render('about', { topicos: topicos })
})


// Cursos
// Renderiza courses.ejs enviando todos os cursos disponíveis
app.get('/cursos', function(req, res) {
  res.render('courses', { courses: db.courses.getAll() });
})

app.get('/alunos', function(req, res) {
  res.render('students', { courses: db.courses.getAll() });
})

// Renderiza a página do formulário de inscrição do curso identificado pelo `id` recebido como paramêtro
app.get('/cursos/inscricao', function(req, res) {
  var id = req.query.id;
  var course = db.courses.findById(id);

  res.render('show-course', { course: course, error: false });
})

// Recebe o request de formulário de inscrição no curso
app.post('/cursos/inscricao', function(req, res) {
  // Recupera o curso pelo id recebido como paramêtro
  var id = req.query.id;
  var course = db.courses.findById(id);

  // Cria um objeto para o aluno com os valores recebidos do form
  var student = {
    name:    req.body.name,
    phone:   req.body.phone,
    gender:  req.body.gender,
    address: req.body.address,
    latitude:  req.body.addressLatitude,
    longitude: req.body.addressLongitude,
  }

  // Verificar se há vagas disponíveis no curso
  if( course.students.length < course.limit ){
    // se sim, adciona um aluno e tela de sucesso
    course.students.push(student);

    // e calcula o numero de estudantes homens e mulheres para gerar o gráfico
    var males = 0;
    var females = 0;

    for (var i = 0; i < course.students.length; i++) {
      var student = course.students[i];

      if(student.gender === 'm')
        males = males + 1;
      else if(student.gender === 'f')
        females = females + 1;

    }

    // Renderizar o html passando as variaveis
    res.render('registration-success', { 
      course: course, 
      student: student, 
      gendersMale: males, 
      gendersFemale: females,
    });

  } else {
    // se não, retorna tela com indicação de erro.
    res.render('show-course', { course: course, error: true })
  }

});


app.listen(3001, function () {
  console.log('Example app listening on port 3001!');
});






var frases = [
  'Yoga é a chave dourada que abre a porta para a paz, tranquilidade e alegria',
  'Mude a maneira que olha as coisas e as coisas que olha mudarão',
  'Yoga é como música. O ritmo do corpo, a melodia da mente e a harmonia da alma criam a sinfonia da vida',
  'Se você tem tempo para facebook também tem tempo para Yoga…',
]

var allCourses = [
  { 
    id: 0,
    title: 'Iniciante', 
    description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent in neque condimentum, dignissim libero sit amet, blandit felis.', 
    hours: ['Seg, Qua: 17hrs', 'Ter, Qui: 17hrs' ],
    limit: 10,
    students: []
  },
  { 
    id: 1,
    title: 'Intermediario', 
    description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent in neque condimentum, dignissim libero sit amet, blandit felis.', 
    hours: ['Seg, Qua: 17hrs', 'Ter, Qui: 17hrs' ], 
    limit: 5,
    students: []
  }
];

// Simulador de Banco de dados!
var db = {
  courses: {
    getAll: function() {
      return allCourses;
    },
    findById: function(id) {
      var courseFound;

      for (var i = 0; i < allCourses.length; i++) {
        var course = allCourses[i];
        if(course.id.toString() === id)
          courseFound = course;
      }

      return courseFound;
    }
  }
};

